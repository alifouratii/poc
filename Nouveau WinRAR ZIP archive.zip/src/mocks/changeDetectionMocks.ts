import { changeDetectionTreeNdvi20260605To20260613Response } from "./changeDetectionTreeNdvi20260605To20260613Response";
import type {
  ChangeDetectionApiResponse,
  ChangeDetectionDateItem,
  ChangeDetectionRequest,
  VegetationIndex,
} from "../types/robocare";

type NormalizedChangeDetectionRequest = {
  id: string;
  dates: ChangeDetectionDateItem[];
  index: VegetationIndex;
  field_zone: string | null;
};

type ChangeDetectionMock = {
  request: NormalizedChangeDetectionRequest;
  response: ChangeDetectionApiResponse;
};

const changeDetectionMocks: ChangeDetectionMock[] = [
  {
    request: {
      id: "1290b561-2499-4dfe-9224-2ad3d7ea0fae",
      dates: [
        {
          date: "2026-06-13",
          provider: "S2",
        },
        {
          date: "2026-06-05",
          provider: "S2",
        },
      ],
      index: "NDVI",
      field_zone: null,
    },
    response:
      changeDetectionTreeNdvi20260605To20260613Response as unknown as ChangeDetectionApiResponse,
  },
];

function normalizeScope(fieldZone: string | null | undefined) {
  return fieldZone ?? null;
}

function normalizeIndex(index: ChangeDetectionRequest["index"]) {
  return index ?? "NDVI";
}

function normalizeDates(dates: ChangeDetectionDateItem[]) {
  return dates
    .map((item) => `${item.date}|${item.provider}`)
    .sort()
    .join("::");
}

function requestToNormalized(
  request: ChangeDetectionRequest,
): NormalizedChangeDetectionRequest | null {
  if ("dates" in request) {
    return {
      id: request.id,
      dates: request.dates,
      index: normalizeIndex(request.index),
      field_zone: normalizeScope(request.field_zone),
    };
  }

  return {
    id: request.id,
    dates: [
      {
        date: request.date_right,
        provider: request.provider,
      },
      {
        date: request.date_left,
        provider: request.provider,
      },
    ],
    index: normalizeIndex(request.index),
    field_zone: normalizeScope(request.field_zone),
  };
}

function matchesRequest(
  mock: ChangeDetectionMock,
  request: ChangeDetectionRequest,
) {
  const normalizedRequest = requestToNormalized(request);

  if (!normalizedRequest) {
    return false;
  }

  return (
    mock.request.id === normalizedRequest.id &&
    mock.request.index === normalizedRequest.index &&
    normalizeDates(mock.request.dates) ===
      normalizeDates(normalizedRequest.dates) &&
    mock.request.field_zone === normalizedRequest.field_zone
  );
}

export function findChangeDetectionMock(request: ChangeDetectionRequest) {
  return (
    changeDetectionMocks.find((mock) => matchesRequest(mock, request)) ?? null
  );
}

export function getChangeDetectionAvailableRequests() {
  return changeDetectionMocks.map((mock) => mock.request);
}
